import chai from "chai"

chai.should()

describe('Check Sum', () => {
  it('1+1 == 2', () => {
    const res = 1 + 1
    res.should.equal(2)
  });

});
