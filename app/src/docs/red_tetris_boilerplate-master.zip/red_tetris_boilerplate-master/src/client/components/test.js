import React from 'react'

export const Tetris = () => {
  return (
    <Board/>
  )
}

export const Board = () => {
  return (
    <div/>
  )
}
