export const ping = () => {
  return {
    type: 'server/ping'
  }
}
